# Bing Map lite
It is a unofficial version map based on bing map api, all the thanks go to the [official website](https://msdn.microsoft.com/en-us/library/mt712542.aspx). hope the web-map will be useful for you.

# Time line

on 2018-03-25 morning, start and finish the first version, just enjoy.
