# maxmap
It is a map test thread
