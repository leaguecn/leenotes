# MyGMap

This is the Google Map lite version. For simple life and lite view.

If you have any suggestion, donot hesitate to contact with me.

The first version is not view by Chinese mainland network, i must give out me applogies.

# Other things

I will add the some usefull features into the website.

In the following days working on the website Map, i will add the Baidu, Tencent, Gaode, Bing Map to enrich MyGMap.


# Revised mark

2018-03-09

